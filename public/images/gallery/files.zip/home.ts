import {
  AfterViewInit,
  Component,
  computed,
  effect,
  ElementRef,
  inject,
  Input,
  NgZone,
  OnDestroy,
  signal,
  ViewChild,
} from '@angular/core';

import { FormsModule } from '@angular/forms';

import { Router, RouterLink } from '@angular/router';

import { toSignal } from '@angular/core/rxjs-interop';

import { animate, state, style, transition, trigger } from '@angular/animations';

import { CourseService, Course } from '../../services/course';

import { CourseCategoryService, CourseCategory } from '../../services/course-category';

import { Stats } from './stats/stats';

import { CourseSession, CourseSessionService } from '../../services/course-session-service';

import { StatsService } from '../../services/stats-services';

import { CircleProgress } from '../../shared/component/circle-progress/circle-progress';

import { Programvenue } from './programvenue/programvenue';

import { AnimatedHero } from '../animated-hero/animated-hero';

import { StatCounter } from '../../shared/component/stat-counter/stat-counter';

import { FeaturedCourse, FeaturedCourseService } from '../../services/featured-course';

import { HomePartnersComponent } from './home-partners/home-partners.component';

import { HomeTestimonialsComponent } from './home-testimonials/home-testimonials.component';

import { catchError } from 'rxjs/operators';

import { of } from 'rxjs';
import { StatisticsSectionHomeComponent } from './statistics-section-home/statistics-section-home.component';

export interface WorkCategory {
  id: number;

  title: string;

  aos?: string;

  delay?: number;
}

export interface AcademicResearch {
  title: string;
}

export interface Accreditation {
  icon: string;
  title: string;
  description: string;
}

interface MenuCategory {
  id: string;

  name: string;

  slug: string;

  courses: Course[];
}

@Component({
  selector: 'app-home',

  imports: [
    FormsModule,
    RouterLink,
    Stats,
    Programvenue,
    CircleProgress,
    AnimatedHero,
    StatCounter,
    HomePartnersComponent,
    HomeTestimonialsComponent,
    StatisticsSectionHomeComponent,
  ],

  templateUrl: './home.html',

  styleUrl: './home.scss',

  animations: [
    trigger('accordionExpand', [
      state(
        'collapsed',

        style({
          height: '0',
          opacity: '0',
          overflow: 'hidden',
          paddingTop: '0',
          paddingBottom: '0',
          marginTop: '0',
        }),
      ),

      state(
        'expanded',

        style({
          height: '*',
          opacity: '1',
          overflow: 'hidden',
          paddingTop: '*',
          paddingBottom: '*',
          marginTop: '*',
        }),
      ),

      transition('collapsed <=> expanded', [animate('400ms cubic-bezier(0.4, 0, 0.2, 1)')]),
    ]),

    trigger('expandResearch', [
      state(
        'collapsed',

        style({
          height: '0',
          overflow: 'hidden',
        }),
      ),

      state(
        'expanded',

        style({
          height: '*',
          overflow: 'hidden',
        }),
      ),

      transition('* <=> *', [animate('350ms ease')]),
    ]),
  ],
})
export class Home implements AfterViewInit, OnDestroy {
  // ============================================================
  // INPUT
  // ============================================================

  @ViewChild('impactSection')
  impactSection!: ElementRef<HTMLElement>;

  // Featured-courses horizontal carousel track.
  @ViewChild('featuredTrack')
  featuredTrack?: ElementRef<HTMLElement>;

  impactVisible = signal(false);

  private impactObserver?: IntersectionObserver;

  private readonly ngZone = inject(NgZone);

  ngAfterViewInit(): void {
    // Wait until the view is completely rendered
    setTimeout(() => {
      this.observeImpactSection();
    });
  }

  ngOnDestroy(): void {
    this.impactObserver?.disconnect();
  }

  private observeImpactSection(): void {
    if (!this.impactSection?.nativeElement) {
      return;
    }

    this.impactObserver = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];

        if (entry?.isIntersecting) {
          this.ngZone.run(() => {
            this.impactVisible.set(true);
          });

          this.impactObserver?.disconnect();
        }
      },
      {
        threshold: 0.15,
      },
    );

    this.impactObserver.observe(this.impactSection.nativeElement);
  }

  @Input()
  propertySaleOptions: {
    name: string;
    prices: string;
    photo: string;
    offers: string;
  }[] = [];

  // ============================================================
  // SEARCH
  // ============================================================

  searchPlaceHolder = $localize`Enter Course name,`;

  searchQuery = signal('');

  // ============================================================
  // SERVICES
  // ============================================================

  private readonly courseService = inject(CourseService);

  private readonly courseCategoryService = inject(CourseCategoryService);

  private readonly router = inject(Router);

  private readonly sessionService = inject(CourseSessionService);

  private readonly statsService = inject(StatsService);

  private readonly featuredCourseService = inject(FeaturedCourseService);

  // ============================================================
  // COURSES
  // ============================================================

  readonly courses = toSignal(this.courseService.courses$, {
    initialValue: [] as Course[],
  });

  readonly coursesLoading = toSignal(this.courseService.isLoading$, {
    initialValue: true,
  });

  readonly coursesLoaded = toSignal(this.courseService.hasLoaded$, {
    initialValue: false,
  });

  readonly coursesError = toSignal(this.courseService.error$, {
    initialValue: null,
  });

  // ============================================================
  // CATEGORIES
  // ============================================================

  readonly categories = toSignal(this.courseCategoryService.categories$, {
    initialValue: [] as CourseCategory[],
  });

  // ============================================================
  // STATS
  // ============================================================

  readonly stats = toSignal(this.statsService.stats$, {
    initialValue: [],
  });

  // Single headline stat used as the badge overlaid on the
  // "Trusted Worldwide" image (e.g. "30+ Years of Experience").
  readonly heroStat = computed(() => this.stats()[0]);

  // ============================================================
  // FEATURED
  // ============================================================

  readonly featuredCoursesData = toSignal(
    this.courseService.getFeatured().pipe(catchError(() => of([] as Course[]))),
    {
      initialValue: [] as Course[],
    },
  );

  readonly featuredCourses = computed(() => {
    const courses = this.featuredCoursesData();

    const sessions = this.courseSessions();

    return courses.map((course) => {
      const courseSessions = sessions[course.id] ?? [];

      const nextSession = courseSessions[0];

      return {
        ...course,

        currentPrice: nextSession?.price ?? 0,
      };
    });
  });

  scrollFeatured(direction: 1 | -1): void {
    this.featuredTrack?.nativeElement.scrollBy({
      left: direction * 320,
      behavior: 'smooth',
    });
  }

  // ============================================================
  // COURSE SESSIONS
  // ============================================================

  private readonly courseSessions = signal<Record<string, CourseSession[]>>({});

  private readonly sessionsLoading = signal<Record<string, boolean>>({});

  private readonly sessionsLoaded = signal<Record<string, boolean>>({});

  private readonly sessionsError = signal<Record<string, string | null>>({});

  // ============================================================
  // CONSTRUCTOR
  // ============================================================

  constructor() {
    effect(() => {
      const courses = this.courses();

      if (!this.coursesLoaded()) {
        return;
      }

      for (const course of courses) {
        if (!course?.id) {
          continue;
        }

        this.loadCourseSessions(course.id);
      }
    });
  }

  // ============================================================
  // STATS
  // ============================================================

  showAllStats = signal(false);

  visibleStats = computed(() => {
    return this.showAllStats() ? this.stats() : this.stats().slice(0, 2);
  });

  toggleStats(): void {
    this.showAllStats.update((value) => !value);
  }

  // ============================================================
  // SESSION LOADING
  // ============================================================

  loadCourseSessions(courseId: string): void {
    if (this.sessionsLoaded()[courseId] || this.sessionsLoading()[courseId]) {
      return;
    }

    this.sessionsLoading.update((current) => ({
      ...current,
      [courseId]: true,
    }));

    this.sessionsError.update((current) => ({
      ...current,
      [courseId]: null,
    }));

    this.sessionService
      .getByCourse(courseId)
      .pipe(
        catchError((error) => {
          this.sessionsError.update((current) => ({
            ...current,
            [courseId]: error?.message ?? 'Unable to load course sessions.',
          }));

          return of([] as CourseSession[]);
        }),
      )
      .subscribe({
        next: (sessions) => {
          this.courseSessions.update((current) => ({
            ...current,
            [courseId]: sessions ?? [],
          }));

          this.sessionsLoaded.update((current) => ({
            ...current,
            [courseId]: true,
          }));

          this.sessionsLoading.update((current) => ({
            ...current,
            [courseId]: false,
          }));
        },

        error: () => {
          this.sessionsLoading.update((current) => ({
            ...current,
            [courseId]: false,
          }));
        },
      });
  }

  // ============================================================
  // SESSION HELPERS
  // ============================================================

  getCourseSessions(courseId: string): CourseSession[] {
    return this.courseSessions()[courseId] ?? [];
  }

  getNextSession(courseId: string): CourseSession | undefined {
    return this.getCourseSessions(courseId)[0];
  }

  // ============================================================
  // DELIVERY MODES
  // ============================================================

  uniqueDeliveryModes = computed(() => {
    const sessions = Object.values(this.courseSessions()).flat();

    const modes = new Set<string>();

    for (const session of sessions) {
      const mode = session?.deliveryMode;

      if (mode) {
        modes.add(String(mode));
      }
    }

    for (const course of this.courses()) {
      if (Array.isArray(course.deliveryModes)) {
        for (const mode of course.deliveryModes) {
          if (mode) {
            modes.add(String(mode));
          }
        }
      }
    }

    return Array.from(modes).sort();
  });

  // ============================================================
  // CATEGORY MENU
  // ============================================================

  menuCategories = computed<MenuCategory[]>(() => {
    const cats = this.categories();

    const crs = this.courses();

    return cats

      .filter((category) => category.isActive)

      .map((category) => ({
        id: category.id,

        name: category.name,

        slug: category.slug,

        courses: crs.filter((course) => course.categoryId === category.id && course.isActive),
      }))

      .filter((group) => group.courses.length > 0)

      .sort(
        (a, b) =>
          (cats.find((c) => c.id === a.id)?.displayOrder ?? 0) -
          (cats.find((c) => c.id === b.id)?.displayOrder ?? 0),
      );
  });

  // Cycled through by index for the flat category grid; icons are
  // purely decorative since categories don't carry their own icon field.
  private readonly categoryIcons: string[] = [
    'bi-boxes',
    'bi-cpu',
    'bi-graph-up-arrow',
    'bi-diagram-3',
    'bi-people',
    'bi-shield-check',
    'bi-cart-check',
    'bi-clipboard-check',
    'bi-cash-coin',
    'bi-kanban',
    'bi-tools',
    'bi-fuel-pump',
  ];

  getCategoryIcon(index: number): string {
    return this.categoryIcons[index % this.categoryIcons.length];
  }

  // ============================================================
  // ACCORDION (retained, currently unused by the flat category
  // grid template — kept in case the accordion UI is wanted back)
  // ============================================================

  expandedCategories = signal<Set<string>>(new Set());

  toggleCategory(id: string): void {
    this.expandedCategories.update((set) => {
      const newSet = new Set(set);

      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }

      return newSet;
    });
  }

  isExpanded(id: string): boolean {
    return this.expandedCategories().has(id);
  }

  // ============================================================
  // SEARCH
  // ============================================================

  searchResults = computed(() => {
    const query = this.searchQuery().trim().toLowerCase();

    if (query.length < 2) {
      return [];
    }

    return this.courses()

      .filter((course) => {
        if (!course.isActive) {
          return false;
        }

        const name = course.name?.toLowerCase() ?? '';

        const code = course.code?.toLowerCase() ?? '';

        const description = course.shortDescription?.toLowerCase() ?? '';

        const tags = Array.isArray(course.tags) ? course.tags : [];

        return (
          name.includes(query) ||
          code.includes(query) ||
          description.includes(query) ||
          tags.some((tag) => String(tag).toLowerCase().includes(query))
        );
      })

      .slice(0, 8);
  });

  openCourse(course: Course): void {
    this.router.navigate(['/courses', course.slug]);

    this.searchQuery.set('');
  }

  search(): void {
    const query = this.searchQuery().trim();

    if (!query) {
      this.router.navigate(['/course/list']);

      return;
    }

    this.router.navigate(['/course/list'], {
      queryParams: {
        search: query,
      },
    });
  }

  // ============================================================
  // RESEARCH
  // ============================================================

  showAllResearch = signal(false);

  visibleResearch = computed(() => {
    if (this.showAllResearch()) {
      return this.AcademicResearchInnovation;
    }

    return this.AcademicResearchInnovation.slice(0, 10);
  });

  toggleResearch(): void {
    this.showAllResearch.update((value) => !value);
  }

  // ============================================================
  // STATIC WORK CATEGORIES
  // ============================================================

  workCategories: WorkCategory[] = [
    {
      id: 1,
      title: 'Class Training',
      aos: 'fade-down',
      delay: 100,
    },

    {
      id: 2,
      title: 'Online Training',
      aos: 'fade-down',
      delay: 50,
    },

    {
      id: 3,
      title: 'InHouse Training',
      aos: '',
      delay: 200,
    },
  ];

  // ============================================================
  // ACCREDITATIONS / WHY US
  // (previously the "Why Choose Us" feature grid; repurposed as
  // the icon grid in the "Get Certified" section)
  // ============================================================

  accreditations: Accreditation[] = [
    {
      icon: 'bi-globe-americas',
      title: 'Global Delivery',
      description: 'Open courses across leading international venues, plus in-house delivery anywhere.',
    },
    {
      icon: 'bi-patch-check',
      title: 'Accredited Certification',
      description: 'Every programme is benchmarked against internationally recognised standards.',
    },
    {
      icon: 'bi-person-workspace',
      title: 'Expert Facilitators',
      description: 'Practitioner-led sessions grounded in real business and research experience.',
    },
    {
      icon: 'bi-sliders',
      title: 'Tailored Programmes',
      description: "Content adapted to your organisation's culture, sector, and strategic goals.",
    },
  ];

  // ============================================================
  // RESEARCH AREAS
  // ============================================================

  AcademicResearchInnovation: AcademicResearch[] = [
    { title: 'Research Design & Methodology' },
    { title: 'Academic Writing & Publishing' },
    { title: 'Grant Proposal Development' },
    { title: 'Data Analysis & Research' },
    { title: 'Policy Impact & Research Communication' },
    { title: 'Research Ethics & Integrity' },
    { title: 'Digital Transformation in Academia' },
    { title: 'Institutional Research & Global Rankings' },
    { title: 'Research Commercialisation & Innovation' },
    { title: 'Artificial Intelligence in Research' },
    { title: 'Research Funding & International Grants' },
    { title: 'Research Leadership & Supervision' },
    { title: 'Systematic Literature Review' },
    { title: 'Scientific Writing & Journal Publication' },
    { title: 'Research Impact Assessment' },
    { title: 'Open Science & Research Data Management' },
    { title: 'Academic Collaboration & Partnerships' },
    { title: 'Monitoring & Evaluation for Research Projects' },
    { title: 'Technology Transfer & Innovation Management' },
    { title: 'Research Project Management' },
  ];

  protected starIndices: any;
}
